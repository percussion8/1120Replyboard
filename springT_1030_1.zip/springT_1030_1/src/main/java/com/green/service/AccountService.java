package com.green.service;

import java.util.List;

import com.green.domain.AccountDTO;

public interface AccountService {
	public void register(AccountDTO acc);
	public List<AccountDTO> getList();
	public List<AccountDTO> getSerial(String serial);
	public AccountDTO getLatest(String serial);
	public float getBalance(String serial);
	
}
