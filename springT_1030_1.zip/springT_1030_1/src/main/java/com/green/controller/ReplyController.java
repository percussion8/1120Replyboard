package com.green.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.green.domain.Criteria;
import com.green.domain.ReplyVO;
import com.green.service.ReplyService;

import lombok.Setter;


@RestController
@RequestMapping("/replies/*")
public class ReplyController {
	@Setter(onMethod_=@Autowired)
	private ReplyService service;
	
	@PostMapping(value = "/new", consumes = "application/json;charset=utf-8", produces = {MediaType.TEXT_PLAIN_VALUE})
	public ResponseEntity<String> create(@RequestBody ReplyVO reply){
		System.out.println("리플라이컨트롤러에서 댓글 vo: " + reply);
		System.out.println("댓글입력 갯수: " + service.register(reply));
		return service.register(reply) == 1?
				new ResponseEntity<>("success", HttpStatus.OK) : 
					new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		
	}
	
	@GetMapping(value = "/page/{bno}/{page}", produces = {MediaType.APPLICATION_XML_VALUE, MediaType.APPLICATION_JSON_UTF8_VALUE})
	public ResponseEntity<List<ReplyVO>> getList(
			@PathVariable("page") int page,
			@PathVariable("bno") Long bno
			){
		System.out.println("리플라이컨트롤러에서 전체 목록 조회...........................");
		Criteria crit = new Criteria(page, 10);
		System.out.println(crit);
		return new ResponseEntity<>(service.getList(crit, bno), HttpStatus.OK);
	}
	
	@GetMapping(value = "/{rno}", produces = {MediaType.APPLICATION_XML_VALUE, MediaType.APPLICATION_JSON_UTF8_VALUE})
	public ResponseEntity<ReplyVO> get(@PathVariable("rno") Long rno){
		System.out.println("리플라이컨트롤러에서 받은 rno = "+ rno);
		return new ResponseEntity<>(service.getR(rno), HttpStatus.OK);
	}
	
	@DeleteMapping(value = "/{rno}", produces = {MediaType.TEXT_PLAIN_VALUE})
	public ResponseEntity<String> remove(@PathVariable("rno") Long rno){
		System.out.println("리플라이컨트롤러에서 삭제" + rno);
		return service.remove(rno) == 1?
				new ResponseEntity<>("success", HttpStatus.OK) :
					new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
	}
	
	@PatchMapping(value = "/{rno}", consumes = "application/json", produces = {MediaType.TEXT_PLAIN_VALUE})
	public ResponseEntity<String> modify(
			@RequestBody ReplyVO reply, @PathVariable("rno") Long rno){
		reply.setRno(rno);
		System.out.println("리플라이컨트롤러의 수정:" + rno);
		return service.modify(reply) == 1?
				new ResponseEntity<>("success", HttpStatus.OK) :
					new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
	}
	
	
	
	
}
